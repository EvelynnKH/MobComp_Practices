//
//  W04_ClassAssignmentTests.swift
//  W04_ClassAssignmentTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_ClassAssignment

struct W04_ClassAssignmentTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
