//
//  W04_ClassAssignmentApp.swift
//  W04_ClassAssignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_ClassAssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
