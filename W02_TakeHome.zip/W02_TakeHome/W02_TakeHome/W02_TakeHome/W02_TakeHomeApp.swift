//
//  W02_TakeHomeApp.swift
//  W02_TakeHome
//
//  Created by student on 22/09/25.
//

import SwiftUI

@main
struct W02_TakeHomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
