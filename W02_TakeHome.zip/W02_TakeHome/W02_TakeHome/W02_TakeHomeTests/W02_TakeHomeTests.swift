//
//  W02_TakeHomeTests.swift
//  W02_TakeHomeTests
//
//  Created by student on 22/09/25.
//

import Testing
@testable import W02_TakeHome

struct W02_TakeHomeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
