//
//  W05_Practice1Tests.swift
//  W05_Practice1Tests
//
//  Created by student on 09/10/25.
//

import Testing
@testable import W05_Practice1

struct W05_Practice1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
