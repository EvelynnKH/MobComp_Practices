//
//  W05_Practice1App.swift
//  W05_Practice1
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_Practice1App: App {
    var body: some Scene {
        WindowGroup {
            TaskListView()
        }
    }
}
