//
//  Fruit.swift
//  W05_Practice
//
//  Created by student on 09/10/25.
//

// lebih cocok pakai swift file untuk model

//import Foundation
//
//struct Fruit: Identifiable, Codable, Hashable {
//    let UUID: UUID // Universal Unique ID. dibuatkan oleh swiftnya dan unik
//    let id: String // A001
//    let name: String // Apple
//    let color: String // Green
//
//    // identifiable = who's who. siapa yang siapa
//    // codable = kalau struct ini bisa komunikasi dengan file lain / API
//    // hasable = swift bisa melakukan komparasi atau track codenya
//
//    ForEach (fruits, id: \.id) (fruit) in {
//        // untuk setiap fruits yang dipunyai, dia punya id yang unik. bisa dikenali dari object id. kalau gada identifiable, ga bisa dikenali
//    }
//}
