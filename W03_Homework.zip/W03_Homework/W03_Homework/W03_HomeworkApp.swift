//
//  W03_HomeworkApp.swift
//  W03_Homework
//
//  Created by student on 29/09/25.
//

import SwiftUI

@main
struct W03_HomeworkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
