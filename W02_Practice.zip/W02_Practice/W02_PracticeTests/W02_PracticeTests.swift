//
//  W02_PracticeTests.swift
//  W02_PracticeTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Practice

struct W02_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
