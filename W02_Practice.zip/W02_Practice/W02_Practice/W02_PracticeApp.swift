//
//  W02_PracticeApp.swift
//  W02_Practice
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
