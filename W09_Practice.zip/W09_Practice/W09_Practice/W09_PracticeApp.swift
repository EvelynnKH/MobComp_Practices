//
//  W09_PracticeApp.swift
//  W09_Practice
//
//  Created by student on 06/11/25.
//

import SwiftUI

@main
struct W09_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
